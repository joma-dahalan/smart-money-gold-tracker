import tempfile
import time
import unittest
from pathlib import Path

from fastapi.testclient import TestClient

from app import ROOT, create_app, load_config


class ApiTests(unittest.TestCase):
    def test_delta_and_flow_range_endpoints(self):
        with tempfile.TemporaryDirectory() as d:
            cfg = load_config()
            cfg["recording"]["sqlite_path"] = str(Path(d) / "api.db")
            cfg["recording"]["enabled"] = False
            app = create_app(cfg, start_sources=False, root=ROOT)
            hist = app.state.ctx.history
            now = int(time.time() * 1000)
            s0 = (now - 120_000) // 5000 * 5000
            hist.add_flow([(s0, 8800, 400000.0, 100000.0, 5, 90.0),       # 4400.0
                           (s0, 8810, 50000.0, 10000.0, 1, 11.0),         # 4405.0
                           (s0 + 5000, 8800, 20000.0, 220000.0, 3, 50.0),
                           (s0 + 60_000, 8800, 1000.0, 1000.0, 1, 1.0)])
            with TestClient(app) as c:
                r = c.get("/api/flow/range", params={"t0": s0 - 1000, "t1": s0 + 20_000, "p0": 4399.0, "p1": 4401.0}).json()
                self.assertEqual((r["buy"], r["sell"], r["delta"], r["trades"]), (420000, 320000, 100000, 8))   # 4405 and the later slot excluded
                self.assertEqual(r["slotsInRange"], 2)
                r2 = c.get("/api/flow/range", params={"t0": s0 + 20_000, "t1": s0 - 1000, "p0": 4410.0, "p1": 4390.0}).json()  # swapped args
                self.assertEqual(r2["trades"], 9)      # 5+1+3: the +60 s slot is outside the window
                dl = c.get("/api/delta", params={"minutes": 10, "step": 60}).json()
                self.assertEqual(sum(x["buy"] for x in dl["rows"]), 471000)
                self.assertEqual(sum(x["sell"] for x in dl["rows"]), 331000)
                self.assertTrue(all(x["t"] % 60000 == 0 for x in dl["rows"]))
                self.assertEqual(c.get("/api/heat").json()["bins"], [])      # empty history stays empty


if __name__ == "__main__":
    unittest.main()
