# JOMA GOLD

A clean, single-screen chart platform for gold (XAUUSD) built around **your broker's price** (OANDA or MT5), an **indicator library**, and **real recorded liquidity** — nothing is simulated.

عربي: منصة شارت واحدة مرتبة للذهب، بسعر وسيطك (OANDA أو MT5)، مع مكتبة مؤشرات، وسيولة مسجلة فعلاً. الشرح الكامل بالعربي: `docs/README_AR.md`.

## Run

1. Install Python 3.10+ (64-bit). Windows: double-click `install.bat`, then `start.bat`. Linux/macOS: `pip install -r requirements.txt && ./start.sh`.
2. Put your broker credentials in **`config.local.json`** (copy `config.local.json.example`; this file is never shared):
   ```json
   {"oanda": {"token": "YOUR_OANDA_TOKEN", "account_id": "101-001-XXXXXXX-001"}}
   ```
   MT5 (Windows): keep the terminal open and logged in; the symbol is auto-detected.
3. Run `doctor.bat` (or `python doctor.py`) to check the connection. Open <http://127.0.0.1:8080>.

## What's on the screen

| Area | What it does |
|---|---|
| **Indicators** (`ƒx`) | Library of 29 indicators + 5 liquidity layers. Add, tweak (⚙), hide or remove from the chip bar. Your set is remembered. |
| **Tools** | Measure box (liquidity / flow / OANDA inside a rectangle), Long / Short planner, Replay. |
| **Strip** | Hover OHLC, order-book imbalance ±$10, liquidity colour scale, feed status. |
| **Right edge** | Live liquidity profile with the nearest bid / ask walls. |

Indicators: trend (SMA, EMA, WMA, Hull, VWAP, Bollinger, Keltner, Donchian, Supertrend, Parabolic SAR, Ichimoku), momentum (RSI, MACD, Stochastic, CCI, ATR, ADX), volume (Volume, OBV, Volume Profile), structure (Market Structure BOS/CHoCH, Order Blocks, Fair Value Gaps, Equal Highs/Lows, Liquidity Sweeps, Sessions, Previous Day/Week levels, Auto Fibonacci, Premium/Discount).
Liquidity layers: Heatmap, Profile, Large Trades, Delta & CVD, OANDA client orders.

Add your own indicator in one small file: `docs/ADDING_INDICATORS.md`.

## Honest notes

- Indicators are our own implementations of standard, public formulas — not copies of any commercial script. Volume means the broker's **tick volume**.
- Liquidity comes from the order books of gold-linked venues (shifted onto your broker's price) and OANDA's client-order book. Spot gold has no public order book; these are proxies, labelled as such. History only exists from the moment the server started recording.
- It is an analysis tool, not financial advice. There is no auto-trading.

## Folders

```
app.py  doctor.py  config.json  config.local.json (yours)   start.bat  start.sh  install.bat
backend/    price sources (OANDA, MT5, venues), liquidity engine, recorder, history store
frontend/   index.html · css/ · js/app.js (chart + liquidity) · js/indicators/ (framework + library) · vendor/
tests/      python tests + tests/js (indicator math) — run:  python tests/run_all.py
docs/       README_AR.md · ADDING_INDICATORS.md · SOURCES.md · CHANGELOG.md
data/       recorded history (created automatically)
```
